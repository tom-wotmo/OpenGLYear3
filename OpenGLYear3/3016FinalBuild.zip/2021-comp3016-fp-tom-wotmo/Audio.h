#include <iostream>
#include <Windows.h>
#include <mmsystem.h>


void JumpSound();


void JumpSound()
{
	PlaySound(TEXT("media/audio/jump.wav"), NULL, SND_FILENAME | SND_ASYNC);

}